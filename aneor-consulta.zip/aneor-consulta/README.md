# Consulta de Perfil Rodoviário — ANEOR

Ferramenta de consulta online que verifica se uma empresa tem perfil para obras rodoviárias com base nos critérios da ANEOR.

## Como funciona

1. Usuário digita o CNPJ
2. Sistema consulta a Receita Federal via BrasilAPI (gratuito, sem cadastro)
3. CNAEs são analisados automaticamente
4. IA (Claude) gera um parecer com recomendação prática

## Vereditos possíveis

- ✅ **Tem perfil** — Associada Efetiva (construtoras de rodovias, CNAE 4211-1/01 e similares)
- ⚠️ **Perfil parcial** — Associada Colaboradora (fornecedoras, consultoras, terraplenagem, materiais)
- ❌ **Sem perfil** — Fora do escopo rodoviário

## Deploy no Vercel (gratuito)

### Opção 1 — Via GitHub (recomendado)

1. Crie uma conta em [github.com](https://github.com) (gratuito)
2. Crie um repositório novo chamado `consulta-rodoviaria`
3. Faça upload dos dois arquivos: `index.html` e `vercel.json`
4. Acesse [vercel.com](https://vercel.com) e clique em **"Add New Project"**
5. Conecte seu GitHub e selecione o repositório
6. Clique em **Deploy** — pronto!
7. Você receberá um link tipo: `https://consulta-rodoviaria.vercel.app`

### Opção 2 — Via Vercel CLI

```bash
npm install -g vercel
cd pasta-do-projeto
vercel
```

### Opção 3 — Arrastar e soltar (mais fácil)

1. Acesse [vercel.com/new](https://vercel.com/new)
2. Arraste a pasta `aneor-consulta` para a área de upload
3. Clique em Deploy

## Arquivos

- `index.html` — aplicação completa (HTML + CSS + JS em um arquivo)
- `vercel.json` — configuração do Vercel
- `README.md` — este arquivo

## Tecnologias

- HTML/CSS/JS puro (sem dependências)
- [BrasilAPI](https://brasilapi.com.br) — dados da Receita Federal (gratuito)
- [Claude API](https://anthropic.com) — geração do parecer por IA

## Observação sobre a API do Claude

A aplicação usa a API do Claude diretamente do navegador. Para uso em produção com volume alto, 
considere criar um backend simples (ex: Vercel Functions) para proteger a chave de API.
Para uso interno com poucos acessos, funciona direto.
